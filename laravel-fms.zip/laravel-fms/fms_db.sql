-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 31, 2023 at 10:20 AM
-- Server version: 5.7.36
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
CREATE TABLE IF NOT EXISTS `files` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `folder_id` int(10) UNSIGNED DEFAULT NULL,
  `created_by_id` int(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `files_deleted_at_index` (`deleted_at`),
  KEY `110370_5a6720aac53d3` (`folder_id`),
  KEY `110370_5a6720aad15f8` (`created_by_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `uuid`, `created_at`, `updated_at`, `deleted_at`, `folder_id`, `created_by_id`) VALUES
(1, '97654620-a14f-11ed-a30f-eb195b0a0812', '2023-01-31 04:41:13', '2023-01-31 04:41:13', NULL, NULL, 1),
(2, '9b486a80-a14f-11ed-9d74-fd80c79be83b', '2023-01-31 04:41:19', '2023-01-31 04:41:19', NULL, NULL, 1),
(3, 'a093d100-a14f-11ed-a44b-2be6c6a73c51', '2023-01-31 04:41:28', '2023-01-31 04:41:28', NULL, NULL, 1),
(4, 'a5879a60-a14f-11ed-9790-9bc42ffcf77d', '2023-01-31 04:41:36', '2023-01-31 04:41:42', '2023-01-31 04:41:42', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

DROP TABLE IF EXISTS `folders`;
CREATE TABLE IF NOT EXISTS `folders` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_by_id` int(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `folders_deleted_at_index` (`deleted_at`),
  KEY `110369_5a671f8a18acf` (`created_by_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `folders`
--

INSERT INTO `folders` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`, `created_by_id`) VALUES
(1, 'Group', '2023-01-31 04:16:55', '2023-01-31 04:16:55', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_id` bigint(20) UNSIGNED DEFAULT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
(1, 'App\\File', 1, '237d3a98-75db-4b1a-a497-c86d4f871471', 'filename', 'IMG-6306', 'IMG-6306.jpg', 'image/jpeg', 'public', 'public', 1747892, '[]', '[]', '[]', '[]', 1, '2023-01-31 04:41:12', '2023-01-31 04:41:13'),
(2, 'App\\File', 2, 'e7dc4a4f-a004-4267-9af0-832a7d285e6d', 'filename', 'meghana_resume_pdf-(1)', 'meghana_resume_pdf-(1).pdf', 'application/pdf', 'public', 'public', 121461, '[]', '[]', '[]', '[]', 1, '2023-01-31 04:41:18', '2023-01-31 04:41:19'),
(3, 'App\\File', 3, '8a08e383-bd2c-44c7-9680-3c51827a5e20', 'filename', 'Group 45427', 'Group-45427.png', 'image/png', 'public', 'public', 500736, '[]', '[]', '[]', '[]', 1, '2023-01-31 04:41:27', '2023-01-31 04:41:28'),
(4, 'App\\File', 4, 'f819d001-14d1-428a-9003-4abd029cf4b5', 'filename', 'green-circle', 'green-circle.svg', 'image/svg+xml', 'public', 'public', 309, '[]', '[]', '[]', '[]', 1, '2023-01-31 04:41:34', '2023-01-31 04:41:37');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2018_01_23_133813_create_1516707493_roles_table', 1),
(3, '2018_01_23_133817_create_1516707497_users_table', 1),
(4, '2018_01_23_133818_add_5a671eace54b3_relationships_to_user_table', 1),
(5, '2018_01_23_134200_create_1516707719_folders_table', 1),
(6, '2018_01_23_134201_add_5a671f8b8f045_relationships_to_folder_table', 1),
(7, '2018_01_23_134649_create_1516708008_files_table', 1),
(8, '2018_01_23_134650_add_5a6720ac71ed7_relationships_to_file_table', 1),
(9, '2018_01_23_140132_update_1516708892_files_table', 1),
(10, '2018_01_23_140134_add_5a67241eb75bb_relationships_to_file_table', 1),
(11, '2018_01_23_141542_update_1516709742_files_table', 1),
(12, '2018_01_23_141544_add_5a6727705ce42_relationships_to_file_table', 1),
(13, '2018_01_23_162733_add_5a674655b480f_relationships_to_file_table', 1),
(14, '2018_02_20_125149_add_5a8bfdc54146c_relationships_to_file_table', 1),
(15, '2018_02_26_124612_create_1519641971_payments_table', 1),
(16, '2018_02_26_124613_add_5a93e5779057c_relationships_to_payment_table', 1),
(17, '2018_02_26_124617_update_1519641977_roles_table', 1),
(18, '2018_02_26_124619_update_1519641979_users_table', 1),
(19, '2018_02_26_124621_add_5a93e57d265cb_relationships_to_user_table', 1),
(20, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(21, '2022_06_14_061628_create_media_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `stripe_plan_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `created_at`, `updated_at`, `price`, `stripe_plan_id`) VALUES
(1, 'Administrator (can create other users)', '2023-01-31 01:39:16', '2023-01-31 01:39:16', NULL, NULL),
(2, 'Simple user', '2023-01-31 01:39:16', '2023-01-31 01:39:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `stripe_customer_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_until` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `110368_5a671eab11d6a` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `role_id`, `stripe_customer_id`, `role_until`) VALUES
(1, 'Admin', 'admin@admin.com', '$2y$10$u5EBywjXyKqzJ1BlHxiO1uAfQl30K5jq1amO9TCfheqZXm5hMFe62', 'G3km6Qc3CT9UhQZfOCctMpt929FezL5qzUJrWzQJAlwML1qnzOx6lkTrJ67O', '2023-01-31 01:39:16', '2023-01-31 01:39:16', 1, NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
